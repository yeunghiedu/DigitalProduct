<?php

include WPV_THEME_OPTIONS.'docs.php';
