<?php echo gloria_core::bk_footer_localize();?>
<?php echo gloria_core::bk_get_footer_instagram();?>
<div class="footer footer-2">
    <?php echo gloria_core::bk_get_footer_widgets();?>
    <?php echo gloria_core::bk_get_footer_lower();?>
</div>