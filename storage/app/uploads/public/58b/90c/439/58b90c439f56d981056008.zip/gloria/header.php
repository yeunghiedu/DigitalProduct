<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<?php
    gloria_get_header();
?>