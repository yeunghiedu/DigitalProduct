<?php echo gloria_core::bk_footer_localize();?>
<div class="footer">
    <?php echo gloria_core::bk_get_footer_widgets();?>
    <?php echo gloria_core::bk_get_footer_lower();?>
</div>